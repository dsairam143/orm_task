from django.contrib import admin
from .models import Movies

class BookAdmin(admin.ModelAdmin):
    list_display = ('movie', 'language', 'year')


admin.site.register(Movies, BookAdmin)
# Register your models here.
