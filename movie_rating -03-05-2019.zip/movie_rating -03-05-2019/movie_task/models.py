from django.db import models

# Create your models here.

class Movies(models.Model):
    movie = models.CharField(max_length=50)
    language = models.CharField(max_length=10)
    year = models.IntegerField()

