from django.db import models

# Create your models here.

class Movies(models.Model):
    movie = models.CharField(max_length=50)
    language = models.CharField(max_length=10)
    year = models.IntegerField()

    def __str__(self):
        return self.movie

class Cast(models.Model):
    actor = models.CharField(max_length=50)
    role = models.CharField(max_length=50)
    cast_data = models.ForeignKey(Movies, on_delete=models.CASCADE)

