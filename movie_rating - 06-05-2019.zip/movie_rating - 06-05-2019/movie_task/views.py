from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Movies,Cast
# Create your views here.

def Home(request):
    home_movies = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    return render(request, 'my_templates/home.html', {'home_movies':home_movies})

def Movie_info(request):

    return render(request, 'my_templates/movie-info.html')

def Home2(request):
    data = [
        {'name':'sairam', "marks":233, 'mail':"sairam@123"},
        {'name': 'srinu', "marks": 234, 'mail': "srinu@123.com"},
        {'name': 'bhanu', "marks": 555, 'mail': "banu@ddsfds.com"},
        {'name': 'kiran', "marks": 233, 'mail': "kiran@eefsdf.com"},
    ]
    return render(request, 'home.html', {"students":data})

def MoviesData(request):
    print('Method type = ', request.method)
    if request.method == 'GET':
        "SELECT * FROM orm_movies_data.movie_task_movies;"
        movies = Movies.objects.all()
        return render(request, 'display_movies.html', {"movies":movies})

    elif request.method == 'POST':
        movie = request.POST['movie']
        lang = request.POST['lang']
        y = request.POST['y']

        movi = Movies(movie = movie, language=lang, year=y)
        movi.save()
        "SELECT * FROM orm_movies_data.movie_task_movies;"
        movies = Movies.objects.all()
        return render(request, 'display_movies.html', {"movies": movies})

def MoviesDelete(request, year):

    try:
        mo = Movies.objects.get(id= year)

        mo.delete()
    except:
        pass

    "SELECT * FROM orm_movies_data.movie_task_movies;"
    movies = Movies.objects.all()
    return render(request, 'display_movies.html', {"movies": movies})

def MoviesUpdate(request, id):
    if request.method == "GET":
        movie = Movies.objects.get(id = id)

        return render(request, 'form.html', {"movie":movie})
    elif request.method == "POST":
        mov = Movies.objects.get(id = id)
        mov.movie = request.POST['movie']
        mov.language = request.POST['lang']
        mov.year = request.POST['y']
        mov.save()
        return redirect('movie_data')
def MovieCast(request, id):

    mov = Movies.objects.get(id = id)
    cast = Cast(actor='sairam', role='actor', cast_data=mov)
    cast.save()
    cast = mov.cast_set.all()
    return render(request, 'my_templates/cast-info.html', {"Movie":mov, "cast":cast})
# def Name(request):
#     return HttpResponse('<h1>Hello Bhanu </h1>')
#
# def Login(request):
#     return render(request, 'login.html')
#
# def Home2(request):
#     return render(request, 'home2.html')