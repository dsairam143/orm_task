from django.contrib import admin
from .models import Movies, Cast

class BookAdmin(admin.ModelAdmin):
    list_display = ('movie', 'language', 'year')

class CastAdmin(admin.ModelAdmin):
    list_display = ('actor', 'role', 'cast_data')
admin.site.register(Movies, BookAdmin)
admin.site.register(Cast, CastAdmin)
# Register your models here.
