from django.apps import AppConfig


class MovieTaskConfig(AppConfig):
    name = 'movie_task'
